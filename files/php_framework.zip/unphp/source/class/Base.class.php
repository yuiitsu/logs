<?php
if(!defined("IN_ONLYFU")){header('HTTP/1.1 404 Not Found');} 

class Base{	
	public $_DB,$_sys,$_cache,$_data,$_model;
	public $_template,$_lang;
	public function __construct(){
		$this->_cache=new Cache();
		$this->_data=$this->getdata();
		$default_route=Route::load_config('route');
		$controller=$this->_data['controller']?$this->_data['controller']."_data":$default_route['controller'].'_data';
		$this->_model=new $controller;
		$this->_template=new Template('');
	}
	
	public function getdata(){
		return array_merge($_POST,$_GET);
	}

	public function dump($d){
		echo "<pre>";
		print_r($d);
	}
}
?>
