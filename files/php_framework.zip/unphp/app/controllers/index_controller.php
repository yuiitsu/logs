<?php
if(!defined("IN_ONLYFU")){header('HTTP/1.1 404 Not Found');} 

class index extends myBase{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		
		include $this->_template->load('index');
	}
}
?>
