<?php
return array('lang' => 'simplified_chinese',);
?>