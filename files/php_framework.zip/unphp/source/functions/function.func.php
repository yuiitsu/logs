<?php
if(!defined('IN_ONLYFU')) {
	exit('Access Denied');
}
function __autoload($class_name) {
	if(strpos($class_name,'_data')===false){
		$file_name=trim(str_replace('_','/',$class_name),'/').'.class.php';
		if ( file_exists( SYS_CLASS_PATH . $file_name ) ) { 
			return require_once( SYS_CLASS_PATH . $file_name );
		}elseif(file_exists(CUSTOM_CLASS_PATH.$file_name)){
			return require_once( CUSTOM_CLASS_PATH . $file_name );
		}else{
			exit('Error: the class is not exists,check the file : '.SYS_CLASS_PATH.$file_name.' or '.CUSTOM_CLASS_PATH . $file_name);
		}
	}else{
		$file_name=$class_name.'.php';
		$file_path=IN_ADMIN?CUSTOM_ADMIN_MODEL_PATH.$file_name:CUSTOM_MODEL_PATH.$file_name;
		
		if(file_exists($file_path)){
			return require_once($file_path);
		}else{
			exit('Error: the model class is not exists,check the file : '.$file_path);
		}
		
	}
	return false;
}
?>