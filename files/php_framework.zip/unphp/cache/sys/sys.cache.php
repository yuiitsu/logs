<?php
//system cache file, DO NOT modify me!
//Created: 2012-07-27 11:36:37
//filename :  
 
return array (
  'sitename' => '一个PHP框架',
  'keywords' => '一个PHP框架',
  'description' => '一个PHP框架',
  'url' => 'http://www.yourdomain.com/',
  'language' => 'simplified_chinese',
);
?>