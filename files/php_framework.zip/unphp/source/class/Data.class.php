<?php
if(!defined("IN_ONLYFU")){header('HTTP/1.1 404 Not Found');} 

class Data{	
	public $_DB;
	public function __construct(){
		$this->_DB=new Model();
		
	}
}
?>
