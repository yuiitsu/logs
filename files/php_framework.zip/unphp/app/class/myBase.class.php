<?php
if(!defined("IN_ONLYFU")){header('HTTP/1.1 404 Not Found');} 

class myBase extends Base{	
	public $_sys;
	public function __construct(){
		parent::__construct();
		//读取站点配置文件
		$this->_sys=$this->_cache->get('sys');
		define("SYS_URL",$this->_sys['url']); //站点URL
		define("SYS_SITENAME",$this->_sys['sitename']);  //站点名称
	}
}
?>
