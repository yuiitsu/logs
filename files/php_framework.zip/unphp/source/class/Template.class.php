<?php
if(!defined("IN_ONLYFU")){header('HTTP/1.1 404 Not Found');} 

class Template{	
	public $_lang;
	public function __construct($lang){
		if($lang){
			$language=new language();  
			$this->_lang=$language->get($lang['lang']);
		}
	}
	
	public function load($file, $templateid = 0,$styleid = 0, $tpldir = ''){
		$file .="";
		$filebak = $file;
		$tpldir = $tpldir ? $tpldir : DEFAULT_TPLDIR;
		$templateid = $templateid ? $templateid : TEMPLATEID;
		$tplfile =$tplfile?$tpldir.'/'.$file.'.htm': CUSTOM_VIEWS_PATH.$tpldir.'/'.$file.'.htm';
		$objfile = CUSTOM_CACHETEMP_PATH.$tpldir.'/'.($styleid ? $styleid."_" : "").$file.'.tpl.php';		
		if($templateid != 1 && !file_exists($tplfile)) {
			$tplfile =CUSTOM_VIEWS_PATH.$filebak.'.htm';
		}
		@$this->checktplrefresh($tplfile, $tplfile,$styleid, filemtime($objfile), $templateid, $tpldir);

		return $objfile;
	}
	
	public function checktplrefresh($maintpl, $subtpl,$styleid, $timecompare, $templateid, $tpldir) {
		$tplrefresh=1;
		if(empty($timecompare) || $tplrefresh == 1 || ($tplrefresh > 1 && !($GLOBALS['timestamp'] % $tplrefresh))) {
			if(empty($timecompare) || @filemtime($subtpl) > $timecompare) {
				$this->parse_template($maintpl, $templateid,$styleid, $tpldir,$timecompare);
				return TRUE;
			}
		}
		return FALSE;
	}
	
	public function parse_template($tplfile, $templateid,$styleid=0, $tpldir,$timestamp) {
		$nest = 6;
		$basefile = $file = basename($tplfile, '.htm');
		if(!is_dir(CUSTOM_CACHETEMP_PATH.$tpldir)){
			@mkdir(CUSTOM_CACHETEMP_PATH.$tpldir,0777);
		}

		$objfile = CUSTOM_CACHETEMP_PATH.$tpldir.'/'.($styleid ? $styleid."_" : "").$file.'.tpl.php';

		$filepathf=$tpldir?$tpldir:CUSTOM_VIEWS_PATH;

		if(!@$fp = fopen($tplfile, 'r')) {
			echo "View does not exist!Plese check ".$filepathf.'/'.$file.".htm";
			$fp=array();
		}

		$template = @fread($fp, filesize($tplfile));
		fclose($fp);

		$var_regexp = "((\\\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)(\[[a-zA-Z0-9_\-\.\"\'\[\]\$\x7f-\xff]+\])*)";
		$const_regexp = "([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)";

		$headerexists = preg_match("/{(sub)?template\s+header\}/", $template) || $basefile == 'header_ajax';
		$subtemplates = array();
		for($i = 1; $i <= 3; $i++) {
			if($this->strexists($template, '{subtemplate')) {
				$template = preg_replace("/[\n\r\t]*\{subtemplate\s+([a-z0-9_:]+)\}[\n\r\t]*/ies", "self::stripvtemplate('\\1', 1,'".$tpldir."')", $template);
			}
		}

		$template = preg_replace("/[\n\r\t]*\{csstemplate\}[\n\r\t]*/ies", $this->loadcsstemplate('\\1'), $template);
		$template = preg_replace("/([\n\r]+)\t+/s", "\\1", $template);
		$template = preg_replace("/\<\!\-\-\{(.+?)\}\-\-\>/s", "{\\1}", $template);
		$template = preg_replace("/\{lang\s+(.+?)\}/ies", "self::languagevar('\\1')", $template);
		$template = preg_replace("/\{faq\s+(.+?)\}/ies", "faqvar('\\1')", $template);
		$template = preg_replace("/\{\s*data_call\s*\(\s*([0-9]+)\s*\)\s*\}/s", "<?php data_call('\\1'); ?>", $template);
		$template = str_replace("{LF}", "<?=\"\\n\"?>", $template);

		$template = preg_replace("/\{(\\\$[a-zA-Z0-9_\[\]\'\"\$\.\x7f-\xff]+)\}/s", "<?=\\1?>", $template);
		$template = preg_replace("/$var_regexp/es", "self::addquote('<?=\\1?>')", $template);
		
		$template = preg_replace("/\<\?\=\<\?\=$var_regexp\?\>\?\>/es", "self::addquote('<?echo \\1?>')", $template);

		/*$headeradd = $headerexists ? "hookscriptoutput('$basefile');" : '';
		if(!empty($subtemplates)) {
			$headeradd .= "\n0\n";
			foreach ($subtemplates as $fname) {
				$headeradd .= "|| checktplrefresh('$tplfile', '$fname', $timecompare, '$templateid', '$tpldir')\n";
			}
			$headeradd .= ';';
		}*/

		$template = "<? if(!defined('IN_ONLYFU')) exit('Access Denied'); {$headeradd}?>\n$template";

		$template = preg_replace("/[\n\r\t]*\{template\s+([a-z0-9_:]+)\}[\n\r\t]*/ies", "self::stripvtemplate('\\1', 0)", $template);
		$template = preg_replace("/[\n\r\t]*\{template\s+(.+?)\}[\n\r\t]*/ies", "self::stripvtemplate('\\1', 0)", $template);
		$template = preg_replace("/[\n\r\t]*\{eval\s+(.+?)\}[\n\r\t]*/ies", "self::stripvtags('<? \\1 ?>','')", $template);
		$template = preg_replace("/[\n\r\t]*\{echo\s+(.+?)\}[\n\r\t]*/ies", "self::stripvtags('<? echo \\1; ?>','')", $template);
		$template = preg_replace("/([\n\r\t]*)\{elseif\s+(.+?)\}([\n\r\t]*)/ies", "self::stripvtags('\\1<? } elseif(\\2) { ?>\\3','')", $template);
		$template = preg_replace("/([\n\r\t]*)\{else\}([\n\r\t]*)/is", "\\1<? } else { ?>\\2", $template);

		for($i = 0; $i < $nest; $i++) {
			$template = preg_replace("/[\n\r\t]*\{loop\s+(\S+)\s+(\S+)\}[\n\r]*(.+?)[\n\r]*\{\/loop\}[\n\r\t]*/ies", "self::stripvtags('<? if(is_array(\\1)) { foreach(\\1 as \\2) { ?>','\\3<? } } ?>')", $template);
			$template = preg_replace("/[\n\r\t]*\{loop\s+(\S+)\s+(\S+)\s+(\S+)\}[\n\r\t]*(.+?)[\n\r\t]*\{\/loop\}[\n\r\t]*/ies", "self::stripvtags('<? if(is_array(\\1)) { foreach(\\1 as \\2 => \\3) { ?>','\\4<? } } ?>')", $template);
			$template = preg_replace("/([\n\r\t]*)\{if\s+(.+?)\}([\n\r]*)(.+?)([\n\r]*)\{\/if\}([\n\r\t]*)/ies", "self::stripvtags('\\1<? if(\\2) { ?>\\3','\\4\\5<? } ?>\\6')", $template);
		}

		$template = preg_replace("/\{$const_regexp\}/s", "<?echo \\1?>", $template);
		$template = preg_replace("/ \?\>[\n\r]*\<\? /s", " ", $template);

		if(!@$fp = fopen($objfile, 'w')) {
			echo "Tpl can't write! Plese check ".CUSTOM_CACHETEMP_PATH;
			$fp=array();
		}

		$template = preg_replace("/\"(http)?[\w\.\/:]+\?[^\"]+?&[^\"]+?\"/e", "self::transamp('\\0')", $template);
		$template = preg_replace("/\<script[^\>]*?src=\"(.+?)\"(.*?)\>\s*\<\/script\>/ise", "self::stripscriptamp('\\1', '\\2')", $template);

		$template = preg_replace("/[\n\r\t]*\{block\s+([a-zA-Z0-9_]+)\}(.+?)\{\/block\}/ies", "self::stripblock('\\1', '\\2')", $template);

		flock($fp, 2);
		fwrite($fp, $template);
		fclose($fp);
	}
	
	public function stripvtemplate($tpl, $sub,$tpldir='') {
		$vars = explode(':', $tpl);
		if(count($vars) > 1){
			$tpl = $vars[1];
			$tpldir .= '../../'.$vars[0];
		}
		$templateid = 0;
		if($sub) {
			return self::loadsubtemplate($tpl, $templateid, $tpldir);
		} else {
			return stripvtags("<? include template('$tpl', '$templateid', '$tpldir'); ?>", '');
		}
	}

	public function loadsubtemplate($file, $templateid = 0, $tpldir = '') {
		global $subtemplates;
		$tpldir = $tpldir ? $tpldir : TPLDIR;
		$templateid = $templateid ? $templateid : TEMPLATEID;

		$tplfile =$tplfile?$tpldir.'/'.$file.'.htm': CUSTOM_VIEWS_PATH.$tpldir.'/'.$file.'.htm';
		if($templateid != 1 && !file_exists($tplfile)) {
			$tplfile = CUSTOM_VIEWS_PATH.$tpldir.'/'.$file.'.htm';
		}
		$content = @implode('', file($tplfile));
		$subtemplates[] = $tplfile;
		return $content;
	}

	public function loadcsstemplate() {
		global $csscurscripts;
		$scriptcss = '<link rel="stylesheet" type="text/css" href="'.$cachedir.'/cache/style_{STYLEID}_common.css?{VERHASH}" />';
		$content = $csscurscripts = '';
		$content = @implode('', file(ROOT.'/'.$cachedir.'/cache/style_'.STYLEID.'_script.css'));
		$content = preg_replace("/([\n\r\t]*)\[CURSCRIPT\s+=\s+(.+?)\]([\n\r]*)(.*?)([\n\r]*)\[\/CURSCRIPT\]([\n\r\t]*)/ies", "cssvtags('\\2','\\4')", $content);
		if($csscurscripts) {
			$csscurscripts = preg_replace(array('/\s*([,;:\{\}])\s*/', '/[\t\n\r]/', '/\/\*.+?\*\//'), array('\\1', '',''), $csscurscripts);
			if(@$fp = fopen(ROOT.'./'.$cachedir.'/cache/scriptstyle_'.STYLEID.'_'.CURSCRIPT.'.css', 'w')) {
				fwrite($fp, $csscurscripts);
				fclose($fp);
			} else {
				exit('Can not write to cache files, please check directory ./'.$cachedir.'/ and ./themedata/cache/ .');
			}
			$scriptcss .='<link rel="stylesheet" type="text/css" href="'.$cachedir.'/cache/scriptstyle_{STYLEID}_{CURSCRIPT}.css?{VERHASH}" />';
		}
		$content = str_replace('[SCRIPTCSS]', $scriptcss, $content);
		return $content;
	}

	public function cssvtags($curscript, $content) {
		global $csscurscripts;
		$csscurscripts .= in_array(CURSCRIPT, explode(',', $curscript)) ? $content : '';
	}

	public function transamp($str) {
		$str = str_replace('&', '&amp;', $str);
		$str = str_replace('&amp;amp;', '&amp;', $str);
		$str = str_replace('\"', '"', $str);
		return $str;
	}

	public function addquote($var) {
		return str_replace("\\\"", "\"", preg_replace("/\[([a-zA-Z0-9_\-\.\x7f-\xff]+)\]/s", "['\\1']", $var));
	}

	public function languagevar($var) {
		return $this->_lang[$var];
	}

	public function faqvar($var) {
		global $_DCACHE;
		include_once ROOT.'/'.$cachedir.'/cache/cache_faqs.php';

		if(isset($_DCACHE['faqs'][$var])) {
			return '<a href="faq.php?action=faq&id='.$_DCACHE['faqs'][$var]['fpid'].'&messageid='.$_DCACHE['faqs'][$var]['id'].'" target="_blank">'.$_DCACHE['faqs'][$var]['keyword'].'</a>';
		} else {
			return "!$var!";
		}
	}

	public function stripvtags($expr, $statement) {
		$expr = str_replace("\\\"", "\"", preg_replace("/\<\?\=(\\\$.+?)\?\>/s", "\\1", $expr));
		$statement = str_replace("\\\"", "\"", $statement);
		return $expr.$statement;
	}

	public function stripscriptamp($s, $extra) {
		$extra = str_replace('\\"', '"', $extra);
		$s = str_replace('&amp;', '&', $s);
		return "<script src=\"$s\" type=\"text/javascript\"$extra></script>";
	}

	public function stripblock($var, $s) {
		$s = str_replace('\\"', '"', $s);
		$s = preg_replace("/<\?=\\\$(.+?)\?>/", "{\$\\1}", $s);
		preg_match_all("/<\?=(.+?)\?>/e", $s, $constary);
		$constadd = '';
		$constary[1] = array_unique($constary[1]);
		foreach($constary[1] as $const) {
			$constadd .= '$__'.$const.' = '.$const.';';
		}
		$s = preg_replace("/<\?=(.+?)\?>/", "{\$__\\1}", $s);
		$s = str_replace('?>', "\n\$$var .= <<<EOF\n", $s);
		$s = str_replace('<?', "\nEOF;\n", $s);
		return "<?\n$constadd\$$var = <<<EOF\n".$s."\nEOF;\n?>";
	}
	
	public function strexists($haystack, $needle) {
		return !(strpos($haystack, $needle) === FALSE);
	}
}
?>
