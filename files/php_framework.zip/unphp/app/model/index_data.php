<?php
if(!defined("IN_ONLYFU")){header('HTTP/1.1 404 Not Found');} 

class index_data extends Data{	
	public function __construct(){
		parent::__construct();
	}
	
	public function getOneMember($uid){
		return $this->_DB->find('members','first',array('conditions'=>array('uid'=>$uid)));
	}
	//商品分类
	public  function getProductType(){
		$proType = $this->_DB->find('product_type','list',array('fields'=>array('type_id','type_name','type_parentid'),'conditions'=>array('type_parentid'=>0)));
		if($proType){
			foreach($proType as $k => $v){
				$d=$this->_DB->find('product_type','list',array('conditions'=>array('type_parentid'=>$v['type_id'])));
				if($d){
					$proType[$k]['childs']=$d;
				}
			}
		}
		return $proType;
	}
	public function shop_product($user_id){
		return $this->_DB->find('product','first',array('fields'=>array('count(pro_id) as num'),'conditions'=>array('user_id'=>$user_id)));
	}
	public function article($id){
		return $this->_DB->find('articles','first',array('conditions'=>array('id'=>$id)));
	}
	/*公告*/
	public function articles(){
		return $this->_DB->find('articles','list',array('conditions'=>array('article_type'=>1),'orders'=>array('id'=>'desc'),'limit'=>array(0,6)));
	}
	/*热排行旁*/
	public function hot_articles(){
		return $this->_DB->find('articles','list',array('fields'=>array('id','title'),'limit'=>array(0,6)));
	}
	public function updatearticles($id,$count){
		$this->_DB->update('articles',array('fields'=>array('browse'=>$count,),'conditions'=>array('id'=>$id)));
	}
	//public function browses(){
		//return $this->_DB->find('product','list',array('orders'=>array('browse'=>'desc'),'limit'=>array(0,6)));
	//}
	//public function new_pros(){
		//return $this->_DB->find('product','list',array('orders'=>array('pro_id'=>'desc'),'limit'=>array(0,6)));
	//}
	public function hot_pros(){
		return $this->_DB->find('product','list',array('orders'=>array('pro_sold'=>'desc'),'limit'=>array(0,6)));
	}

	public function dongtais(){
		return $this->_DB->find('dongtais','list',array(
			'orders'=>array(
				'id'=>'desc',
			),
			'limit'=>array(0,20),
		));
	}
}
?>
