<?php
return array(
	'top_login'=>'登录',
	'login_form_button'=>'登录',
	'reg_text'=>'注册',
	'forget_pass'=>'忘记密码？',
	'login_pass'=>'登录密码',
	'login_email'=>'注册邮箱',
	'login_text'=>'帐户登录',
);
?>