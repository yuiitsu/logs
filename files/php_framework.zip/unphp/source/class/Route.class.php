<?php
if(!defined("IN_ONLYFU")){header('HTTP/1.1 404 Not Found');} 

class Route{	
	private $route_config;
	
	public function __construct(){
	
	}
	
	public function app(){
		$_POST = self::daddslashes($_POST);
		$_GET = self::daddslashes($_GET);
		$_REQUEST = self::daddslashes($_REQUEST);
		$_COOKIE = self::daddslashes($_COOKIE);
		$_FILES = self::daddslashes($_FILES);
		$this->route_config = self::load_config('route'); 
		define('ROUTE_C',$this->get_controller());
		define('ROUTE_M',$this->get_method());
		$this->init();
	}
	
	public function init(){
		$controller_file=IN_ADMIN?CUSTOM_ADMIN_PATH:CUSTOM_CONTROLLER_PATH;
		$controller_file.=ROUTE_C.'_controller.php';
		if(file_exists($controller_file)){
			$class_name=ROUTE_C;
			require($controller_file);
			$class=new $class_name;
			if(method_exists($class,ROUTE_M)){
				call_user_func(array($class,ROUTE_M));
			}else{
				exit('Method does not exist! Plese check function ' .ROUTE_M.' in '.$controller_file);
			}
		}else{
			exit('Controller does not exist! Plese check '.$controller_file);
		}
	}
	
	public static function load_config($file) {
		$config = '';
		$path = file_exists(CUSTOM_CONFIG_PATH.$file.'.config.php')?CUSTOM_CONFIG_PATH.$file.'.config.php':(file_exists(SYS_CONFIG_PATH.$file.'.config.php')?SYS_CONFIG_PATH.$file.'.config.php':'');
		if ($path) {
			$config = include $path;
		}
		return $config;
	}
	
	public static function daddslashes($string, $force = 0) {
		$string=self::dhtmlspecialchars($string);
		!defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
		if(!MAGIC_QUOTES_GPC || $force) {
			if(is_array($string)) {
				foreach($string as $key => $val) {
					$string[$key] = self::daddslashes($val, $force);
				}
			} else {
				$string = addslashes(trim($string));
			}
		}
		return $string;
	}
	
	public function get_controller(){
		$controller = isset($_GET['controller']) && !empty($_GET['controller']) ? $_GET['controller'] : (isset($_POST['controller']) && !empty($_POST['controller']) ? $_POST['controller'] : ''); 
		if(empty($controller)){
			$controller = $this->route_config['controller'];
		}        
		return $controller;
	}
	
	public function get_method(){
		$method = isset($_GET['method']) && !empty($_GET['method']) ? $_GET['method'] : (isset($_POST['method']) && !empty($_POST['method']) ? $_POST['method'] : ''); 
		if(empty($method)){
			$method = $this->route_config['method'];
		}
		return $method;
	}

	private function dhtmlspecialchars($string) {
		if(is_array($string)) {
			foreach($string as $key => $val) {
				$string[$key] = self::dhtmlspecialchars($val);
			}
		} else {
			$string = preg_replace('/&amp;((#(\d{3,5}|x[a-fA-F0-9]{4}));)/', '&\\1',
			str_replace(array('&', '"', '<', '>'), array('&amp;', '&quot;', '&lt;', '&gt;'), $string));
		}
		return $string;
	}
}
?>