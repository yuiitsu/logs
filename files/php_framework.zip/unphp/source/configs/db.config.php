<?php
return array(
	'dbhost' => '127.0.0.1', 
	'dbuser' => 'root',
	'dbpw' => '',
	'dbname' => 'dbname',
	'pconnect' => 0,
	'tablepre' => 'unphp_',
	'dbcharset' => 'utf8',
);
?>
