<? if(!defined('IN_ONLYFU')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?echo SYS_SITENAME?></title>
<meta content="" name="keywords" />
<meta name="description" content="" />
</head>
<body>
<h3>
欢迎使用一个PHP框架
</h3>
<p>
一个PHP框架，已经正常运行
</p>
<p>
你可以在/views/default/index.htm中修改本页面
</p>
<h4>
谢谢！
</h4>
</body>
</html>