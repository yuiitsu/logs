<?php

class Cache{
	private $_DB;

	public function __construct(){
		$this->_DB=new Model();
	}

	public function create($name, $data,$path='') {
		$cache_settings_path=$this->getpath($name,$path);
		if($fp=@fopen($cache_settings_path,'w')){
			$data = "<?php\n//system cache file, DO NOT modify me!\n//Created: ".date("Y-m-d H:i:s")."\n//filename : $filename \n \nreturn ".var_export($data, true).";\n?>";
			@fwrite($fp,$data);
			@fclose($fp);
		}
	}
	

	public function write($name,$data,$path='',$isfile = false){
		$cache_settings_path=$this->getpath($name,$path);
		if($isfile){
			$cache_settings_path .= $name.'.cache.php';
		}
		if($fp=@fopen($cache_settings_path,'w')){
			$data = "<?php\n//system cache file, DO NOT modify me!\n//Created: ".date("Y-m-d H:i:s")."\n//filename : $filename \n \nreturn ".var_export($data, true).";\n?>";
			@fwrite($fp,$data);
			@fclose($fp);
		}else{
			$this->create($name,$data,$path);
		}
	}
	
	public function getpath($name,$path=''){
		if($path){
			$cache_settings_path=$path;
		}else{
			$cache_settings_path=SYS_CACHE_PATH.$name.'.cache.php';
		}
		return $cache_settings_path;
	}

	public function get($name,$path=''){
		$cache = '';
	
		$path = $this->getpath($name,$path);
		if (file_exists($path)) {
			$cache = include $path;
		}
		return $cache;
	} 
	
	public function del($name){
		$cache_path = ONLYFU_CACHEDATA_PATH.$name.'.cache.php';
		if(@unlink($cache_path)){
			return true;
		}
		return false;
	}

	public function getHashPath($id,$cat){
		if(empty($id)){return false;}	
		$id = abs(intval($id));	
		$id = sprintf("%09d", $id);
		$dir1 = substr($id, 0, 3);
		$cat = $cat ? $cat."/" : '';
		$folder=CUSTOM_CACHEHASH_PATH.$cat.$dir1."/";
		$dir2 = substr($id, 3, 2);
		$folder=$folder."".$dir2."/";
		$dir3 = substr($id, 5, 2);
		$folder=$folder."".$dir3."/";
		$dir4 = substr($id, 7, 2);
		$folder=$folder."".$dir4."/";
		if (!file_exists($folder)){
			@umask(0);
			preg_match_all('/([^\/]*)\/?/i', $folder, $atmp);
			$base = ($atmp[0][0] == '/') ? '/' : '';
			foreach ($atmp[1] AS $val){
				if ('' != $val){
					$base .= $val;
					if ('..' == $val || '.' == $val){
						$base .= '/';
						continue;
					}
				}else{
					continue;
				}
				$base .= '/';
				if (!file_exists($base)){
					if (@mkdir($base, 0777)){
						@chmod($base, 0777);
					}
				}
			}			
		}
		clearstatcache();
		return $folder;
	}

}