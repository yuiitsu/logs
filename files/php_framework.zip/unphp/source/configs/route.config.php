<?php
return array('controller' => 'index', 'method' => 'index');
?>